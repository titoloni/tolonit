import unittest
from unittest.mock import patch, mock_open
import json
from src.utils.parameter import ParameterClass

class TestParameterClass(unittest.TestCase):

    def setUp(self):
        # Definindo o JSON simulado para os testes
        self.mock_json_data = json.dumps([
            {
                "base": "CNPJ9",
                "type_process": "delta",
                "last_partition_date": "2023-01-01",
                "previous_partition_date": "2022-12-31",
                "is_to_process": True
            },
            {
                "base": "CNPJ10",
                "type_process": "full",
                "last_partition_date": None,
                "previous_partition_date": "2022-11-30",
                "is_to_process": False
            }
        ])

    @patch("builtins.open", new_callable=mock_open, read_data='[{"base": "CNPJ9", "type_process": "delta", "last_partition_date": "2023-01-01", "previous_partition_date": "2022-12-31", "is_to_process": true}, {"base": "CNPJ10", "type_process": "full", "last_partition_date": null, "previous_partition_date": "2022-11-30", "is_to_process": false}]')
    @patch("sys.argv", ["main.py"])
    def test_load_parameters_from_file(self, mock_file):
        params = ParameterClass()
        self.assertEqual(len(params._json_parameters), 2)
        mock_file.assert_called_once_with("utils//default_parameters.json", "r")

    @patch("sys.argv", ["main.py", "--PARAM", '[{"base":"CNPJ9","type_process":"delta","last_partition_date":"2023-01-01","previous_partition_date":"2022-12-31","is_to_process":true}]'])
    def test_load_parameters_from_command_line(self):
        params = ParameterClass()
        self.assertEqual(len(params._json_parameters), 1)
        self.assertEqual(params._json_parameters[0]["base"], "CNPJ9")

    @patch("builtins.open", new_callable=mock_open, read_data='[{"base": "CNPJ9", "type_process": "delta", "last_partition_date": "2023-01-01", "previous_partition_date": "2022-12-31", "is_to_process": true}, {"base": "CNPJ10", "type_process": "full", "last_partition_date": null, "previous_partition_date": "2022-11-30", "is_to_process": false}]')
    def test_get_all_partition_dates(self, mock_file):
        params = ParameterClass()
        partition_dates = params.get_all_partition_dates()
        self.assertIn("2023-01-01", partition_dates)
        self.assertIn("2022-12-31", partition_dates)
        self.assertIn("2022-11-30", partition_dates)

    @patch("builtins.open", new_callable=mock_open, read_data='[{"base": "CNPJ9", "type_process": "delta", "last_partition_date": "2023-01-01", "previous_partition_date": "2022-12-31", "is_to_process": true}, {"base": "CNPJ10", "type_process": "full", "last_partition_date": null, "previous_partition_date": "2022-11-30", "is_to_process": false}]')
    def test_is_to_process(self, mock_file):
        params = ParameterClass()
        self.assertTrue(params.is_to_process("CNPJ9"))
        self.assertFalse(params.is_to_process("CNPJ10"))

    @patch("builtins.open", new_callable=mock_open, read_data='[{"base": "CNPJ9", "type_process": "delta", "last_partition_date": "2023-01-01", "previous_partition_date": "2022-12-31", "is_to_process": true}, {"base": "CNPJ10", "type_process": "full", "last_partition_date": null, "previous_partition_date": "2022-11-30", "is_to_process": false}]')
    def test_get_type_process(self, mock_file):
        params = ParameterClass()
        self.assertEqual(params.get_type_process("CNPJ9"), "delta")
        self.assertEqual(params.get_type_process("CNPJ10"), "full")

    @patch("builtins.open", new_callable=mock_open, read_data='[{"base": "CNPJ9", "type_process": "delta", "last_partition_date": "2023-01-01", "previous_partition_date": "2022-12-31", "is_to_process": true}, {"base": "CNPJ10", "type_process": "full", "last_partition_date": null, "previous_partition_date": "2022-11-30", "is_to_process": false}]')
    def test_get_last_base_date(self, mock_file):
        params = ParameterClass()
        self.assertEqual(params.get_last_base_date("CNPJ9"), "2023-01-01")
        self.assertEqual(params.get_last_base_date("CNPJ10"), None)

    @patch("builtins.open", new_callable=mock_open, read_data='[{"base": "CNPJ9", "type_process": "delta", "last_partition_date": "2023-01-01", "previous_partition_date": "2022-12-31", "is_to_process": true}, {"base": "CNPJ10", "type_process": "full", "last_partition_date": null, "previous_partition_date": "2022-11-30", "is_to_process": false}]')
    def test_get_previous_base_date(self, mock_file):
        params = ParameterClass()
        self.assertEqual(params.get_previous_base_date("CNPJ9"), "2022-12-31")
        self.assertEqual(params.get_previous_base_date("CNPJ10"), "2022-11-30")

    @patch("builtins.open", new_callable=mock_open, read_data='[{"base": "CNPJ9", "type_process": "delta", "last_partition_date": "2023-01-01", "previous_partition_date": "2022-12-31", "is_to_process": true}, {"base": "CNPJ10", "type_process": "full", "last_partition_date": null, "previous_partition_date": "2022-11-30", "is_to_process": false}]')
    def test_get_bases(self, mock_file):
        params = ParameterClass()
        bases = params.get_bases()
        self.assertIn("CNPJ9", bases)
        self.assertIn("CNPJ10", bases)

if __name__ == "__main__":
    unittest.main()
