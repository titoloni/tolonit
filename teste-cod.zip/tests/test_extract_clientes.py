import unittest
from unittest.mock import MagicMock, patch
from pyspark.sql import SparkSession
from src.extract.extract_clientes import extract_clients, _get_max_partition_date
from src.utils.parameter import ParameterClass


class TestExtractClients(unittest.TestCase):

    def setUp(self):
        # Inicializa uma sessão Spark para os testes
        self.spark = SparkSession.builder.master("local").appName("Test").getOrCreate()
        self.mock_parameters = MagicMock(spec=ParameterClass)

        # Cria um DataFrame de exemplo para a view spec_cliente
        data = [("20230101", "Cliente A"), ("20221231", "Cliente B")]
        columns = ["anomesdia", "name"]
        self.spec_cliente_df = self.spark.createDataFrame(data, columns)

        # Define o comportamento do método get_all_partition_dates
        self.mock_parameters.get_all_partition_dates.return_value = {"20230101", "20221231"}

    @patch("src.extract.extract_clientes._get_max_partition_date", return_value=20230101)
    @patch("src.extract.extract_clientes.SparkSession.sql")
    def test_extract_clients(self, mock_spark_sql, mock_get_max_partition_date):
        # Define o DataFrame de retorno para as chamadas SQL simuladas
        mock_spark_sql.side_effect = [
            self.spec_cliente_df  # Retorna o DataFrame na chamada sql()
        ]

        # Cria a view temporária e chama a função
        self.spec_cliente_df.createOrReplaceTempView("spec_cliente")
        result = extract_clients(self.spark, self.mock_parameters)

        # Verificações de que a função extraiu corretamente as partições
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0][0], "20230101")
        self.assertEqual(result[0][1], "last")
        self.assertIsInstance(result[0][2], type(self.spec_cliente_df))

    @patch("src.extract.extract_clientes.SparkSession.sql")
    def test_get_max_partition_date(self, mock_spark_sql):
        # Mock para o retorno do método sql() para simular o resultado de MAX(anomesdia)
        mock_spark_sql.return_value = self.spark.createDataFrame([(20230101,)], ["max_anomesdia"])

        max_date = _get_max_partition_date(self.spark, exclude_date=None)

        # Verificar se a data máxima foi extraída corretamente
        self.assertEqual(max_date, 20230101)
        mock_spark_sql.assert_called_once_with("SELECT MAX(anomesdia) as max_anomesdia FROM spec_cliente")

    def tearDown(self):
        self.spark.stop()


if __name__ == "__main__":
    unittest.main()
