import unittest
from unittest.mock import patch, MagicMock
from src.local_orchestrator import run_workflow

class TestLocalOrchestrator(unittest.TestCase):

    @patch("src.local_orchestrator.SparkSession")
    @patch("src.local_orchestrator.ParameterClass")
    @patch("src.local_orchestrator.extract_clients")
    @patch("src.local_orchestrator.transform_cnpj9")
    @patch("src.local_orchestrator.load_cnpj9")
    def test_run_workflow(self, mock_load_cnpj9, mock_transform_cnpj9, mock_extract_clients, mock_ParameterClass, mock_SparkSession):
        # Mock the SparkSession builder
        mock_spark = MagicMock()
        mock_SparkSession.builder.master().appName().getOrCreate.return_value = mock_spark

        # Mock ParameterClass
        mock_params = MagicMock()
        mock_ParameterClass.return_value = mock_params

        # Mock extract_clients, transform_cnpj9, and load_cnpj9
        mock_clients_data = MagicMock()
        mock_cnpj9_data = MagicMock()
        mock_extract_clients.return_value = mock_clients_data
        mock_transform_cnpj9.return_value = mock_cnpj9_data

        # Call the function to test
        run_workflow()

        # Assertions
        mock_SparkSession.builder.master.assert_called_with("local[*]")
        mock_SparkSession.builder.master().appName.assert_called_with("Encart JOB")
        mock_extract_clients.assert_called_once_with(mock_spark, mock_params)
        mock_transform_cnpj9.assert_called_once_with(mock_spark, mock_clients_data, mock_params)
        mock_load_cnpj9.assert_called_once_with(mock_cnpj9_data)

if __name__ == "__main__":
    unittest.main()
