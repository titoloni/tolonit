import unittest
from unittest.mock import MagicMock, patch

from pyspark.sql import DataFrame
from pyspark.sql import SparkSession

from src.transform.transform_cnpj9 import transform_cnpj9, _get_insert_df, _get_update_df
from src.utils.parameter import ParameterClass


class TestTransformCNPJ9(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.spark = SparkSession.builder.master("local").appName("Test").getOrCreate()

    def setUp(self):
        self.mock_params = MagicMock(spec=ParameterClass)
        self.mock_params.get_last_base_date.return_value = 20230101
        self.mock_params.get_previous_base_date.return_value = 20221231
        self.mock_params.get_type_process.return_value = "delta"

        data = [
            (20230101, "last", self.spark.createDataFrame([(1, "Empresa A", "Ativo")],
                                                          ["num_cpfcnpj", "des_nome_cliente_razao_social",
                                                           "des_cpfcnpj_status"])),
            (20221231, "prev", self.spark.createDataFrame([(1, "Empresa A", "Inativo")],
                                                          ["num_cpfcnpj", "des_nome_cliente_razao_social",
                                                           "des_cpfcnpj_status"]))
        ]
        self.clients_data = data

    @patch("src.transform.transform_cnpj9.cache_cnpj9")
    def test_transform_cnpj9(self, mock_cache_cnpj9):
        # Configura o mock para o cache_cnpj9
        mock_cache_df = self.spark.createDataFrame([(1, "Empresa A", "Ativo")],
                                                   ["num_cpfcnpj", "des_nome_cliente_razao_social",
                                                    "des_cpfcnpj_status"])
        mock_cache_cnpj9.return_value = mock_cache_df

        # Executa o método principal de transformação
        result_df = transform_cnpj9(self.spark, self.clients_data, self.mock_params)

        # Verifica se o DataFrame resultante é uma instância de DataFrame do PySpark
        self.assertIsInstance(result_df, DataFrame)

    def test_get_insert_df(self):
        df_last = self.spark.createDataFrame([(1, "Empresa A", "Ativo")],
                                             ["num_cpfcnpj", "des_nome_cliente_razao_social", "des_cpfcnpj_status"])
        df_prev = self.spark.createDataFrame([], ["num_cpfcnpj", "des_nome_cliente_razao_social", "des_cpfcnpj_status"])

        insert_df = _get_insert_df(df_last, df_prev)

        # Verifica se a coluna de operação foi adicionada corretamente
        self.assertIn("operation", insert_df.columns)
        self.assertEqual(insert_df.select("operation").first()["operation"], "INSERT")

    def test_get_update_df(self):
        df_last = self.spark.createDataFrame([(1, "Empresa A", "Ativo")],
                                             ["num_cpfcnpj", "des_nome_cliente_razao_social", "des_cpfcnpj_status"])
        df_prev = self.spark.createDataFrame([(1, "Empresa A", "Inativo")],
                                             ["num_cpfcnpj", "des_nome_cliente_razao_social", "des_cpfcnpj_status"])

        update_df = _get_update_df(df_last, df_prev)

        # Verifica se a coluna de operação foi adicionada corretamente
        self.assertIn("operation", update_df.columns)
        self.assertEqual(update_df.select("operation").first()["operation"], "UPDATE")

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()


if __name__ == "__main__":
    unittest.main()
